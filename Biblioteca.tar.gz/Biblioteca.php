<?php
	require_once "functions/menu.php";
	head();
	menu();
	footer();
?>
